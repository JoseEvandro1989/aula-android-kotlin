package br.com.fernandosousa.lmsapp

import android.content.Context

object DisciplinaService {
    fun getDisciplinas(context: Context): List<Disciplina> {
        val disciplinas = mutableListOf<Disciplina>()

        for (i in 1..10) {
            val d = Disciplina()
            d.nome = "Disciplina $i"
            d.ementa = "Ementa $i"
            d.professor = "Professor $i"
            d.foto = "https://www.google.com.br/search?q=cachorro&source=lnms&tbm=isch&sa=X&ved=0ahUKEwjlkfav9ffdAhVQo1kKHXczDF0Q_AUIDigB&biw=1440&bih=789#imgrc=IDrd1jl70nAX5M:"
            disciplinas.add(d)
        }

        return disciplinas
    }

}