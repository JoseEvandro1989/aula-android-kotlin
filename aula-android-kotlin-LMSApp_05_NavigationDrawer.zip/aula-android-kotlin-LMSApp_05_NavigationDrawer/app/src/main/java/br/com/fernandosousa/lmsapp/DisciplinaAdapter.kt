package br.com.fernandosousa.lmsapp

import android.support.v7.widget.CardView
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import com.squareup.picasso.Callback
import com.squareup.picasso.Picasso

class DisciplinaAdapter(
        val disciplinas: List<Disciplina>,
        val onClick: (Disciplina) -> Unit
    ): RecyclerView.Adapter<DisciplinaAdapter.DisciplinaViewHolder>() {

    class DisciplinaViewHolder(view: View): RecyclerView.ViewHolder(view) {
        val cardNome: TextView
        val cardImg: ImageView
        val cardView: CardView

        init {
            cardNome = view.findViewById(R.id.card_nome)
            cardImg = view.findViewById(R.id.card_imagem)
            cardView = view.findViewById(R.id.card_disciplinas)
        }
    }

    override fun getItemCount() = this.disciplinas.size

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): DisciplinaViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.adapter_disciplina, parent, false)
        val holder = DisciplinaViewHolder(view)
        return holder
    }

    override fun onBindViewHolder(holder: DisciplinaViewHolder, position: Int) {
        val contexto = holder.itemView.context
        val disciplina = this.disciplinas[position]

        holder.cardNome.text = disciplina.nome

        Picasso.with(contexto)
                .load(disciplina.foto)
                .fit()
                .into(holder.cardImg,
                        object: com.squareup.picasso.Callback{
                            override fun onSuccess() {

                            }

                            override fun onError() {

                            }
                        }
                        )

        holder.itemView.setOnClickListener{onClick(disciplina)}
    }
}


